import json
import boto3

def lambda_handler(event, context):


    tablename = "resume-view-count"
    
    DB = boto3.resource('dynamodb', region_name='us-east-1')
    table = DB.Table(tablename)
    
    # gets the map of the item and increases {'total':#} by one
    count = int((table.get_item(Key={'count': 'count'})['Item']['total'])+1)
    
    # Overwrites {total: "#" } item in DB
    table.put_item(Item={'count': 'count', 'total': count})

    
    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Origin': 'https://xaviercordovajr.com',
            'Access-Control-Allow-Methods': 'GET'
        },
        'body': json.dumps(count)
    }